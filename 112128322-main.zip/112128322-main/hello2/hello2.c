#include <stdio.h>

int main(void)
{
    printf("hello, \t                                                                                                                             \"peter\"");
    printf("\n");
}